# Cat vs Dog YOLO

本專案使用 Ultralytics YOLO 建立一個簡單的貓狗辨識模型，適合用於 Kaggle 貓狗資料集或其他標註格式相仿的影像資料。

## 專案內容
- `114514.py`：主要腳本，用於將原始圖片轉成 YOLO 標註格式並訓練模型
- `requirements.txt`：需要安裝的 Python 套件
- `cat_dog_data.yaml`：YOLO data config，用於訓練時指定訓練集與驗證集
- `raw/train/`：放置原始圖片的資料夾
- `data/train/`, `data/val/`：準備後的 YOLO 格式資料夾

## 需求
- Python 3.8+
- 安裝套件：

```powershell
pip install -r requirements.txt
```

## 資料格式
請將貓狗影像放到 `raw/train/`，圖片檔名必須以 `cat` 或 `dog` 開頭，例如：
- `cat.0.jpg`
- `dog.1.png`
- `cat_123.jpeg`

腳本會根據檔名判斷類別，並將整張圖片視為一個完整的 bounding box 進行 YOLO 訓練。

## 使用方式

### 1. 準備資料

```powershell
python 114514.py --prepare
```

此指令會：
- 從 `raw/train/` 讀取影像
- 隨機分配訓練與驗證集
- 建立 `data/train/images`、`data/train/labels`、`data/val/images`、`data/val/labels`
- 產生 `cat_dog_data.yaml`

### 2. 訓練模型

```powershell
python 114514.py --train
```

訓練結果會儲存在 `runs/detect/cat_dog/`，包含最佳權重檔 `best.pt`。

## 自訂參數

你可以調整參數來控制資料集切分與訓練配置：

```powershell
python 114514.py --prepare --val-ratio 0.2 --seed 42
python 114514.py --train --model yolov8n.pt --epochs 30 --imgsz 640 --batch 16
```

常用參數：
- `--raw-dir`: 原始影像資料夾，預設 `raw/train`
- `--output-dir`: YOLO 資料輸出資料夾，預設 `data`
- `--val-ratio`: 驗證集比例，預設 `0.2`
- `--model`: YOLO 初始權重，預設 `yolov8n.pt`
- `--epochs`: 訓練輪數，預設 `20`
- `--imgsz`: 輸入圖片尺寸，預設 `640`
- `--batch`: 批次大小，預設 `16`

## 資料量建議
你目前有 8000 張資料，建議使用預設 `--val-ratio 0.2`，這會分出 6400 張訓練影像和 1600 張驗證影像。

## 注意事項
- 若 GPU 記憶體不足，可將 `--batch` 調小
- 若資料名稱並非 `cat` 或 `dog` 開頭，請先批次重新命名
- 本專案採用「整張圖的 bounding box」方式，所以適合對單一目標的分類影像

## 範例流程

```powershell
pip install -r requirements.txt
python 114514.py --prepare
python 114514.py --train
```

完成後，可在 `runs/detect/cat_dog/weights/best.pt` 中找到訓練好的模型權重。