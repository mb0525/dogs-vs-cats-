import argparse
import random
import shutil
from pathlib import Path

from PIL import Image
from ultralytics import YOLO

CLASS_NAMES = ["cat", "dog"]


def get_image_size(image_path: Path):
    with Image.open(image_path) as img:
        return img.width, img.height


def create_yolo_label(image_path: Path, label_path: Path):
    image_name = image_path.name.lower()
    if image_name.startswith("cat"):
        class_id = 0
    elif image_name.startswith("dog"):
        class_id = 1
    else:
        raise ValueError(f"Image name must start with 'cat' or 'dog': {image_path}")

    width, height = get_image_size(image_path)
    if width == 0 or height == 0:
        raise ValueError(f"Invalid image dimensions: {image_path}")

    x_center = 0.5
    y_center = 0.5
    w = 1.0
    h = 1.0

    label_path.write_text(f"{class_id} {x_center:.6f} {y_center:.6f} {w:.6f} {h:.6f}\n")


def prepare_dataset(raw_dir: Path, output_dir: Path, val_ratio: float = 0.2, seed: int = 42):
    if not raw_dir.exists():
        raise FileNotFoundError(f"Raw dataset directory not found: {raw_dir}")

    image_files = sorted(
        [p for p in raw_dir.glob("*.*") if p.suffix.lower() in {".jpg", ".jpeg", ".png"}]
    )
    if not image_files:
        raise ValueError(f"No supported images found in {raw_dir}")

    random.seed(seed)
    random.shuffle(image_files)

    train_dir = output_dir / "train"
    val_dir = output_dir / "val"
    for subset_dir in [train_dir, val_dir]:
        (subset_dir / "images").mkdir(parents=True, exist_ok=True)
        (subset_dir / "labels").mkdir(parents=True, exist_ok=True)

    split_index = int(len(image_files) * (1.0 - val_ratio))
    split_index = max(1, min(split_index, len(image_files) - 1))

    for index, image_path in enumerate(image_files):
        subset = "train" if index < split_index else "val"
        dest_image = output_dir / subset / "images" / image_path.name
        shutil.copy2(image_path, dest_image)

        dest_label = output_dir / subset / "labels" / f"{image_path.stem}.txt"
        create_yolo_label(dest_image, dest_label)

    print(f"Prepared dataset in {output_dir}")
    print(f"  train: {split_index} images")
    print(f"  val: {len(image_files) - split_index} images")
    print("Label format: <class> <x_center> <y_center> <width> <height>")
    print("Using full-image bounding boxes for each cat/dog image.")


def write_data_config(config_path: Path, output_dir: Path):
    config_content = f"""
train: {output_dir / 'train' / 'images'}
val: {output_dir / 'val' / 'images'}
names:
  0: cat
  1: dog
""".strip()
    config_path.write_text(config_content)
    print(f"Created YOLO data config: {config_path}")


def train_yolo(data_config: Path, model_name: str, epochs: int, imgsz: int, batch: int, project: str, name: str):
    print("Starting YOLO training...")
    print(f"data: {data_config}")
    print(f"model: {model_name}")
    print(f"epochs: {epochs}")
    print(f"imgsz: {imgsz}")
    print(f"batch: {batch}")

    model = YOLO(model_name)
    model.train(
        data=str(data_config),
        epochs=epochs,
        imgsz=imgsz,
        batch=batch,
        project=project,
        name=name,
        exist_ok=True,
    )

    best_weights = Path(project) / name / "weights" / "best.pt"
    if best_weights.exists():
        print(f"Training complete. Best weights saved to: {best_weights}")
    else:
        print("Training finished, but best.pt not found. Check the training output directory.")


def parse_args():
    parser = argparse.ArgumentParser(description="Prepare and train a YOLO cat-vs-dog detector")
    parser.add_argument("--prepare", action="store_true", help="Prepare raw images into YOLO dataset format")
    parser.add_argument("--train", action="store_true", help="Train YOLO on the prepared dataset")
    parser.add_argument("--raw-dir", type=Path, default=Path("raw/train"), help="Folder with raw cat and dog images")
    parser.add_argument("--output-dir", type=Path, default=Path("data"), help="Output folder for YOLO dataset")
    parser.add_argument("--data-config", type=Path, default=Path("cat_dog_data.yaml"), help="YOLO data config YAML file")
    parser.add_argument("--val-ratio", type=float, default=0.2, help="Validation ratio for dataset split")
    parser.add_argument("--seed", type=int, default=42, help="Random seed for dataset split")
    parser.add_argument("--model", default="yolov8n.pt", help="YOLO model checkpoint to start from")
    parser.add_argument("--epochs", type=int, default=20, help="Number of training epochs")
    parser.add_argument("--imgsz", type=int, default=640, help="Training image size")
    parser.add_argument("--batch", type=int, default=16, help="Batch size for training")
    parser.add_argument("--project", default="runs/detect", help="YOLO project folder")
    parser.add_argument("--name", default="cat_dog", help="YOLO run name")
    return parser.parse_args()


def main():
    args = parse_args()
    if not args.prepare and not args.train:
        print("Please specify --prepare, --train, or both.")
        return

    if args.prepare:
        prepare_dataset(args.raw_dir, args.output_dir, args.val_ratio, args.seed)
        write_data_config(args.data_config, args.output_dir)

    if args.train:
        if not args.data_config.exists():
            raise FileNotFoundError(f"Data config not found: {args.data_config}. Run with --prepare first.")
        train_yolo(args.data_config, args.model, args.epochs, args.imgsz, args.batch, args.project, args.name)


if __name__ == "__main__":
    main()
